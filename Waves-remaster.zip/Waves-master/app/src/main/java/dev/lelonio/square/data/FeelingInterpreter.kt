package dev.lelonio.square.data

/**
 * What a described feeling was understood as.
 *
 * [queries] are ordinary catalogue searches, so the songs come from the same
 * backend, with the same accounts and the same quota, as every other search in
 * the app. Nothing here talks to a network.
 */
data class Feeling(
    val id: String,
    /** "Heartbroken", shown as the heading of the results. */
    val label: String,
    /** One line that says what Waves heard, shown under the heading. */
    val tagline: String,
    /** Catalogue searches that stand for this feeling, best first. */
    val queries: List<String>,
    /** Two ARGB colours for the card behind the heading. */
    val from: Long,
    val to: Long,
)

/**
 * Reads a sentence about how someone feels and says which feeling it is.
 *
 * Deliberately small and local: a phrase list per feeling, a little negation
 * handling ("not happy" is not happy), and a blend of the two strongest
 * feelings when a sentence carries both ("miss her but grateful"). It will not
 * understand everything, which is why the page keeps the normal results under
 * the feeling's and why [interpret] returns null rather than guessing when no
 * feeling is present.
 *
 * English only for now; adding a language is adding phrases to [MOODS].
 * The object is pure Kotlin so it can be unit tested without a device.
 */
object FeelingInterpreter {

    private class Mood(
        val feeling: Feeling,
        /** Phrase to weight. A phrase matches as whole words, so "sad" is not "saddle". */
        val phrases: Map<String, Double>,
        /** What "not <this>" most nearly means. */
        val opposite: String? = null,
    )

    private fun f(
        id: String, label: String, tagline: String, queries: List<String>, from: Long, to: Long,
    ) = Feeling(id, label, tagline, queries, from, to)

    private val MOODS: List<Mood> = listOf(
        Mood(
            f("heartbreak", "Heartbroken", "Songs that sit with the hurt",
                listOf("heartbreak songs", "sad love songs", "songs to cry to"), 0xFF3B2A5C, 0xFF8E3B6E),
            mapOf(
                "heartbroken" to 3.0, "heartbreak" to 3.0, "broke up" to 3.0, "breakup" to 3.0,
                "break up" to 3.0, "broken heart" to 3.0, "dumped" to 2.5, "ex" to 1.0,
                "cheated" to 2.5, "cry" to 2.0, "crying" to 2.5, "tears" to 2.0, "hurt" to 1.5,
                "miss her" to 2.5, "miss him" to 2.5, "miss them" to 2.5, "missing her" to 2.5,
                "missing him" to 2.5, "got over" to 1.5, "moving on" to 1.5,
            ),
            opposite = "romantic",
        ),
        Mood(
            f("sad", "Low", "Gentle company for a heavy day",
                listOf("sad songs", "melancholy indie", "songs for a bad day"), 0xFF1F2A44, 0xFF3F5E8C),
            mapOf(
                "sad" to 3.0, "down" to 1.0, "depressed" to 2.5, "blue" to 1.0, "low" to 1.0,
                "gloomy" to 2.5, "melancholy" to 3.0, "melancholic" to 3.0, "unhappy" to 2.5,
                "empty" to 2.0, "hopeless" to 2.5, "heavy" to 1.0, "bad day" to 2.5,
                "rough day" to 2.5, "grief" to 2.5, "grieving" to 2.5, "numb" to 2.0, "worthless" to 2.0,
            ),
            opposite = "happy",
        ),
        Mood(
            f("lonely", "Lonely", "For when the room is too quiet",
                listOf("lonely songs", "songs about loneliness", "late night sad"), 0xFF14233A, 0xFF4A4E7A),
            mapOf(
                "lonely" to 3.0, "loneliness" to 3.0, "alone" to 2.0, "isolated" to 2.5,
                "nobody" to 1.5, "no one" to 1.0, "left out" to 2.0, "homesick" to 2.5,
            ),
        ),
        Mood(
            f("nostalgic", "Nostalgic", "Back to when it felt different",
                listOf("nostalgic songs", "throwback hits", "songs that feel like memories"), 0xFF5A3A22, 0xFFC08A4D),
            mapOf(
                "nostalgic" to 3.0, "nostalgia" to 3.0, "remember" to 1.5, "memories" to 2.0,
                "memory" to 1.5, "childhood" to 2.5, "old days" to 2.5, "good old" to 2.0,
                "throwback" to 2.5, "back then" to 2.0, "miss the" to 1.5, "reminisce" to 3.0,
                "bittersweet" to 2.5, "high school" to 2.0, "summer of" to 1.5,
            ),
        ),
        Mood(
            f("happy", "Joyful", "Bright songs for a bright mood",
                listOf("feel good songs", "happy pop", "songs that make you smile"), 0xFFE0872D, 0xFFF2C14E),
            mapOf(
                "happy" to 3.0, "joy" to 3.0, "joyful" to 3.0, "cheerful" to 3.0, "great" to 1.0,
                "amazing" to 1.5, "good mood" to 3.0, "smiling" to 2.5, "excited" to 2.0,
                "sunny" to 2.0, "feel good" to 3.0, "feeling good" to 3.0, "on top of the world" to 3.0,
                "ecstatic" to 3.0, "cheer up" to 2.5, "cheer me up" to 3.0, "optimistic" to 2.0,
            ),
            opposite = "sad",
        ),
        Mood(
            f("energy", "Charged", "High energy, turn it up",
                listOf("high energy workout", "pump up songs", "hype songs"), 0xFFB3261E, 0xFFFF7A3D),
            mapOf(
                "energetic" to 3.0, "energy" to 2.0, "hyped" to 3.0, "pumped" to 3.0, "gym" to 2.5,
                "workout" to 2.5, "run" to 1.0, "running" to 2.0, "lift" to 1.0, "lifting" to 2.0,
                "adrenaline" to 3.0, "wired" to 2.0, "restless" to 1.5, "fired up" to 3.0,
                "get going" to 2.0, "wake up" to 1.5, "need energy" to 3.0,
            ),
            opposite = "calm",
        ),
        Mood(
            f("calm", "Calm", "Slow it down and breathe",
                listOf("calm songs", "chill acoustic", "peaceful relaxing music"), 0xFF1E5B63, 0xFF63B5A7),
            mapOf(
                "calm" to 3.0, "relax" to 3.0, "relaxed" to 3.0, "relaxing" to 3.0, "chill" to 3.0,
                "peaceful" to 3.0, "peace" to 2.0, "serene" to 3.0, "mellow" to 3.0, "unwind" to 3.0,
                "wind down" to 3.0, "slow down" to 2.0, "soft" to 1.5, "gentle" to 2.0, "cozy" to 2.5,
                "tranquil" to 3.0, "easy" to 0.5, "breathe" to 2.0,
            ),
            opposite = "energy",
        ),
        Mood(
            f("anxious", "Overwhelmed", "Music to bring the noise down",
                listOf("calming music anxiety", "ambient calm", "soothing songs"), 0xFF22384A, 0xFF5C8E9B),
            mapOf(
                "anxious" to 3.0, "anxiety" to 3.0, "stressed" to 3.0, "stress" to 2.0,
                "overwhelmed" to 3.0, "panic" to 2.5, "nervous" to 2.5, "worried" to 2.5,
                "overthinking" to 3.0, "on edge" to 2.5, "tense" to 2.0, "can't sleep" to 2.0,
                "burnt out" to 2.5, "burned out" to 2.5, "exhausted" to 1.5,
            ),
        ),
        Mood(
            f("focus", "Focused", "Quiet momentum for deep work",
                listOf("focus music", "lofi study beats", "instrumental concentration"), 0xFF1D2B3A, 0xFF3C7A89),
            mapOf(
                "focus" to 3.0, "focused" to 3.0, "study" to 3.0, "studying" to 3.0, "concentrate" to 3.0,
                "concentration" to 3.0, "work" to 1.0, "working" to 1.5, "deep work" to 3.0,
                "homework" to 2.5, "exam" to 2.0, "coding" to 2.5, "productive" to 2.5, "reading" to 1.5,
            ),
        ),
        Mood(
            f("romantic", "In love", "Warm songs for a full heart",
                listOf("love songs", "romantic songs", "songs for someone you love"), 0xFF8C2F4A, 0xFFE87A8F),
            mapOf(
                "love" to 1.5, "in love" to 3.0, "romantic" to 3.0, "romance" to 3.0, "crush" to 2.5,
                "date night" to 3.0, "falling for" to 3.0, "butterflies" to 3.0, "adore" to 2.5,
                "anniversary" to 3.0, "my girlfriend" to 2.0, "my boyfriend" to 2.0, "my wife" to 2.0,
                "my husband" to 2.0, "slow dance" to 3.0, "wedding" to 2.0,
            ),
            opposite = "heartbreak",
        ),
        Mood(
            f("angry", "Fired up", "Let it out",
                listOf("angry songs", "rage rock", "aggressive rap"), 0xFF4A0E0E, 0xFFD13B2A),
            mapOf(
                "angry" to 3.0, "anger" to 3.0, "furious" to 3.0, "mad" to 2.0, "rage" to 3.0,
                "pissed" to 3.0, "annoyed" to 2.0, "frustrated" to 2.5, "irritated" to 2.5,
                "hate" to 2.0, "revenge" to 2.5, "fed up" to 2.5, "livid" to 3.0,
            ),
        ),
        Mood(
            f("confident", "Unstoppable", "Walk in like you own it",
                listOf("confidence boost songs", "boss energy", "empowering songs"), 0xFF3A1F6B, 0xFFB36BFF),
            mapOf(
                "confident" to 3.0, "confidence" to 3.0, "motivated" to 3.0, "motivation" to 3.0,
                "powerful" to 3.0, "unstoppable" to 3.0, "bossed" to 2.0, "boss" to 1.5,
                "ambitious" to 2.5, "determined" to 3.0, "fearless" to 3.0, "glow up" to 3.0,
                "main character" to 3.0, "interview" to 1.5, "hustle" to 2.5, "win" to 1.0,
            ),
        ),
        Mood(
            f("night", "After dark", "Windows down, nowhere to be",
                listOf("night drive songs", "late night vibes", "midnight drive playlist"), 0xFF0E1330, 0xFF2D3A8C),
            mapOf(
                "night drive" to 3.0, "driving" to 2.0, "late night" to 2.5, "midnight" to 2.5,
                "2am" to 3.0, "3am" to 3.0, "after dark" to 3.0, "road trip" to 2.5, "highway" to 2.0,
                "city lights" to 3.0, "neon" to 2.0, "insomnia" to 2.0,
            ),
        ),
        Mood(
            f("rain", "Rainy day", "Soft sounds for grey skies",
                listOf("rainy day songs", "cozy rainy day", "songs for a rainy afternoon"), 0xFF2B3A48, 0xFF7A94A8),
            mapOf(
                "rain" to 3.0, "rainy" to 3.0, "raining" to 3.0, "storm" to 2.0, "grey day" to 3.0,
                "gray day" to 3.0, "cloudy" to 2.0, "drizzle" to 3.0, "thunder" to 2.0,
                "snow" to 1.5, "winter" to 1.5, "cold" to 1.0,
            ),
        ),
        Mood(
            f("sleepy", "Sleepy", "Drift off slowly",
                listOf("sleep music", "songs to fall asleep to", "ambient sleep"), 0xFF10162B, 0xFF39447A),
            mapOf(
                "sleep" to 2.5, "sleepy" to 3.0, "tired" to 2.0, "bedtime" to 3.0, "fall asleep" to 3.0,
                "lullaby" to 3.0, "drowsy" to 3.0, "dream" to 1.5, "exhausted" to 1.0,
            ),
        ),
        Mood(
            f("party", "Party mode", "Dance floor, right now",
                listOf("party songs", "dance hits", "club bangers"), 0xFFAD1F6B, 0xFFFF9A3D),
            mapOf(
                "party" to 3.0, "partying" to 3.0, "dance" to 2.0, "dancing" to 2.5, "club" to 2.0,
                "pregame" to 3.0, "friday night" to 2.5, "turn up" to 3.0, "festival" to 2.5,
                "birthday" to 2.0, "drinks" to 1.5, "dance floor" to 3.0,
            ),
        ),
        Mood(
            f("hopeful", "Hopeful", "Things are starting to turn",
                listOf("hopeful songs", "uplifting songs", "new beginnings songs"), 0xFF2F6B4F, 0xFFA7D86B),
            mapOf(
                "hopeful" to 3.0, "hope" to 2.5, "new beginning" to 3.0, "fresh start" to 3.0,
                "better days" to 3.0, "healing" to 3.0, "recovering" to 2.5, "grateful" to 2.5,
                "thankful" to 2.5, "uplifted" to 3.0, "light at the end" to 3.0, "turning point" to 2.5,
            ),
        ),
    )

    private val BY_ID = MOODS.associateBy { it.feeling.id }

    private val NEGATORS = setOf("not", "no", "never", "dont", "don't", "isnt", "isn't", "cant", "can't", "wont", "won't", "hardly")

    /** Words that say "this is about me", worth a little when two feelings tie. */
    private val INTENT = setOf("feel", "feeling", "feels", "felt", "mood", "vibe", "vibes", "i'm", "im", "i", "me", "my", "when", "after", "need", "want")

    private val WORD = Regex("[a-z0-9']+")

    /** The feeling in [query], or null when it is not about one. */
    fun interpret(query: String): Feeling? {
        val text = query.lowercase().replace('’', '\'')
        val tokens = WORD.findAll(text).map { it.value }.toList()
        if (tokens.isEmpty()) return null

        val scores = HashMap<String, Double>()

        for (mood in MOODS) {
            for ((phrase, weight) in mood.phrases) {
                val parts = WORD.findAll(phrase).map { it.value }.toList()
                var from = 0
                while (true) {
                    val at = indexOfRun(tokens, parts, from)
                    if (at < 0) break
                    from = at + parts.size
                    val negated = (1..2).any { back ->
                        tokens.getOrNull(at - back)?.let { it in NEGATORS } == true
                    }
                    if (negated) {
                        // "not happy" is evidence for the opposite, but less of it:
                        // somebody who is not happy is not necessarily sad.
                        val other = mood.opposite
                        if (other != null) scores.merge(other, weight * 0.85, Double::plus)
                    } else {
                        scores.merge(mood.feeling.id, weight, Double::plus)
                    }
                }
            }
        }
        if (scores.isEmpty()) return null

        val intent = if (tokens.any { it in INTENT }) 0.4 else 0.0
        val ranked = scores.entries.sortedByDescending { it.value }
        val top = ranked.first()

        // A single word has to be a clear feeling word; several words can add
        // up from weaker ones. Otherwise a title that merely contains "low"
        // or "run" would get a feeling it did not ask for.
        val needed = if (tokens.size == 1) 2.5 else 2.0
        if (top.value + intent < needed) return null

        val first = BY_ID.getValue(top.key).feeling
        val second = ranked.getOrNull(1)
            ?.takeIf { it.value >= top.value * 0.6 && it.value >= 2.0 }
            ?.let { BY_ID.getValue(it.key).feeling }
            ?.takeIf { it.id != first.id }

        if (second == null) return first
        return Feeling(
            id = "${first.id}+${second.id}",
            label = "${first.label} · ${second.label}",
            tagline = "A blend of ${first.label.lowercase()} and ${second.label.lowercase()}",
            queries = (first.queries.take(2) + second.queries.take(1)).distinct(),
            from = first.from,
            to = second.to,
        )
    }

    private fun indexOfRun(tokens: List<String>, run: List<String>, from: Int): Int {
        if (run.isEmpty() || tokens.size < run.size) return -1
        var i = from
        while (i <= tokens.size - run.size) {
            var ok = true
            for (j in run.indices) {
                if (tokens[i + j] != run[j]) { ok = false; break }
            }
            if (ok) return i
            i++
        }
        return -1
    }
}
