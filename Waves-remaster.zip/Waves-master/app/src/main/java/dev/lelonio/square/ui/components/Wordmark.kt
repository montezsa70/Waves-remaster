package dev.lelonio.square.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.lelonio.square.R
import dev.lelonio.square.ui.theme.Ink

/**
 * The name: "waves" in Bold Poppins, with one drawn swell beneath it.
 *
 * Sized by its height like the wordmark it replaces, so every header that
 * asked for a 28dp mark still gets one 28dp tall. The swell is a single sine
 * period drawn with the same stroke as the type, which is what makes the word
 * and the line read as one mark.
 */
@Composable
fun SquareWordmark(
    height: Dp,
    modifier: Modifier = Modifier,
    color: Color = Ink,
) {
    val size = with(androidx.compose.ui.platform.LocalDensity.current) { (height * 0.92f).toSp() }
    androidx.compose.foundation.layout.Column(
        modifier.height(height),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        androidx.compose.material3.Text(
            "waves",
            color = color,
            fontFamily = dev.lelonio.square.ui.theme.Poppins,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            fontSize = size,
            lineHeight = size,
            maxLines = 1,
            modifier = Modifier.semantics { contentDescription = "Waves" },
        )
        Canvas(Modifier.height(height * 0.16f).width(height * 1.9f)) {
            val w = this.size.width
            val h = this.size.height
            val stroke = h * 0.34f
            val path = Path()
            val steps = 48
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                val x = t * w
                val y = h / 2f + kotlin.math.sin(t * 2f * Math.PI.toFloat() * 2f) * (h / 2f - stroke / 2f)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = color.copy(alpha = 0.85f), style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/**
 * The launcher art beside the name.
 *
 * The real icon rather than a drawing of one: this is what the user tapped to
 * get here, and showing the same thing is what says the two are one app.
 */
@Composable
fun AppLockup(
    modifier: Modifier = Modifier,
    iconSize: Dp = 28.dp,
    nameHeight: Dp = 14.dp,
    /**
     * What to put the mark on, when it should sit on glass.
     *
     * Null leaves it bare, which is what everywhere but the home header wants:
     * a plate is a control, and a mark in the middle of a login page is not one.
     */
    plate: dev.lelonio.square.ui.glass.backdrop.Backdrop? = null,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        if (plate == null) {
            AppGlyph(iconSize)
        } else {
            AppPlate(iconSize, plate)
        }
        Spacer(Modifier.width(iconSize * 0.32f))
        SquareWordmark(nameHeight)
    }
}

/**
 * The mark on a round pane of the app's own glass.
 *
 * The same material and the same rim as the round buttons — see CircleAction —
 * so it belongs to the same row of controls even though there is nothing to
 * press. What it gives the mark is a place to stand.
 *
 * With something behind it to bend. Glass over the page's own flat colour has
 * nothing to refract and comes out as a grey disc, so the pane is given a wash
 * of the accent the app takes from the artwork that is playing: off-centre, so
 * the film and the rim have a gradient to sit on, and alive, because that
 * colour slides to a new one every time the music changes.
 *
 * Flat, deliberately. This sits in a header that moves with the scroll, and a
 * pane that samples the screen re-photographs it every frame — for a
 * reflection of a colour this already knows.
 */
@Composable
fun AppPlate(
    size: Dp,
    backdrop: dev.lelonio.square.ui.glass.backdrop.Backdrop,
    modifier: Modifier = Modifier,
) {
    val accent = androidx.compose.material3.MaterialTheme.colorScheme.primary
    // The iOS 27 glass, its own edge and light, over the artwork behind the
    // page: that layer stands still while the page scrolls, so the pane is
    // not taken again on every frame of it.
    dev.lelonio.square.ui.glass.LiquidButton(
        onClick = {},
        backdrop = backdrop,
        isInteractive = false,
        modifier = modifier.size(size),
        contentHeight = size,
        contentPadding = 0.dp,
    ) {
        Box(Modifier.size(size), contentAlignment = Alignment.Center) {
            // A veil of the accent the app takes from the artwork playing,
            // light enough that the glass is what reads: it slides to a new
            // colour every time the music changes.
            androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                drawCircle(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        0f to accent.copy(alpha = 0.34f),
                        1f to accent.copy(alpha = 0f),
                        start = androidx.compose.ui.geometry.Offset.Zero,
                        end = androidx.compose.ui.geometry.Offset(this.size.width, this.size.height),
                    ),
                )
            }
            AppGlyph(size * 0.58f)
        }
    }
}

/**
 * The app's mark with no plate under it.
 *
 * The launcher icon is a tile: artwork on a coloured square, because that is
 * what a launcher draws. On a page of the app itself there is nothing for a
 * tile to sit on — it reads as a sticker of the icon rather than as the app's
 * own mark — so what is used is the wave alone, in the page's ink.
 *
 * Drawn from the same file the launcher art came from — see
 * `app/icon-src/wave-square.svg` — rather than from the stroked approximation
 * the themed launcher icon carries, which was a redrawing of it by hand and
 * showed at this size.
 */
@Composable
fun AppGlyph(size: Dp, modifier: Modifier = Modifier, tint: Color = Ink) {
    Icon(
        painter = painterResource(R.drawable.ic_app_mark),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size),
    )
}
